<div id="myModal" class="modal fade text-primary" >
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          <h2 class="modal-title" id="myModalLabel" style=''><b>Website Developers</b></h2>
        </div>
        <div class="modal-body table-responsive">
		<table class='table table-bordered' style=' '>
		<tr bgcolor='#ccc'><th>Name</th><th>Telephone Contact</th><th>Email</th></tr>
		<tr><td>Byarugaba Stephen</td><td>+256706440588</td><td><a href='mailto:byarus45@gmail.com'>byarus45@gmail.com</a></td></tr>
		<tr><td>Kasumba Robert</td><td>+256752615075</td><td><a href='mailto:robein@ymail.com'>robein@ymail.com</a></td></tr>
		</table>
		</div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal" >Close</button>
        </div>
	</div>
	</div>
</div>


<div class='container' style='margin:0px; width:100%; background-color:gold; opacity:0.9;'>
<div class="row">
	<div class="col-md-3 col-lg-3 col-sm-12 col-xs-12">
	<div class="col-md-12 col-lg-12 col-sm-6 col-xs-6">
	<a href='contact us.php'><i class="fa fa-phone fa-2x"></i> Contact us </a>
	</div>
	<div class="col-md-12 col-lg-12 col-sm-6 col-xs-6">
	<a href='about_ayu.php'><i class="fa fa-info fa-2x"></i> About us </a>
	</div>
	<div class="col-md-12 col-lg-12 col-sm-6 col-xs-6">
	
	<a href='articles.php'><i class="fa fa-2x"></i> &nbsp;Posts</a>
	
	</div>
	</div>
	<div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
	Awakening the youth Uganda is a team of enthusiatic youths who are do their best so as to uplift the standards of living of fellow youth in Uganda and Africa
	</div>
	<div class="col-md-3 col-lg-3 col-sm-12 col-xs-12">
	<span class=" " style='display:in-line;'>
	<p style="font-style:italic; font-family:Brush Script MT; font-size:2em;">Social Links</p>
	<a href="https://www.facebook.com/awakenyu?skip_nax_wizard=true"><i class="fa fa-facebook-official fa-2x" style="color:blue;"></i> </a>
	<a href="https://twitter.com/awakenyu1"><i class="fa fa-twitter-square fa-2x" style="color:lightBlue;"></i></a>
	<a href="https://www.youtube.com/channel/UCgEy2o3Yvomh5XZ7f_zT7jQ"><i class="fa fa-youtube fa-2x" style="color:red;"></i></a>
	<a href="https://www.flickr.com/people/137218930@N02/"><i class="fa fa-flickr fa-2x" style=""></i></a>
	<a href="https://www.pinterest.com/awakenyu/"><i class="fa fa-pinterest fa-2x" style=""></i></a>
	<a href="https://www.pinterest.com/awakenyu/"><i class="fa fa-instagram fa-2x" style=""></i></a>
	<a href="https://www.pinterest.com/awakenyu/"><i class="fa fa-tumblr-square fa-2x" style=""></i></a>
	</span>
	</div>
</div>
<div class='row'>

<center>&copy;2015. All rights reserved to Awakening the Youth Uganda| <a href='#' data-toggle="modal" data-target="#myModal"> Contact Developers</a></center>
</div>
</div>