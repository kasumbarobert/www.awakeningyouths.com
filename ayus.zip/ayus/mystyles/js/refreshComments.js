$(setInterval(function(){
	$("#commentsDivision").load("get_comments.php");
},500));